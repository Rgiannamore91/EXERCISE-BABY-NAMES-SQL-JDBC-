/**
 * BabyNameQuery - A class that querys the database baby names 
 * Copyright 2023 Howard Community College
 * @author Ryan Giannamore
 * @version 1.0
 */
import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;
public class BabyNameQuery {
	final static String DB_URL = "jdbc:derby:C:\\Users\\houzi\\Documents\\Java Homework\\Java 2\\Exercise - Baby Names\\babynames-derby (1)\\babynames";
	final static String TEST_QUERY = "SELECT * FROM BABYNAMES FETCH FIRST 1 ROWS ONLY";
	final static String OPTION_ONE = "SELECT * FROM babynames WHERE US_STATE = 'MD' AND DATE_YEAR = 1991 AND GENDER ='M' ORDER BY NUM_BABIES DESC FETCH FIRST 1 ROWS ONLY";
	final static String OPTION_TWO = "SELECT DATE_YEAR FROM babynames WHERE NAME = 'Christopher' AND GENDER = 'M' GROUP BY DATE_YEAR ORDER BY COUNT(*) DESC FETCH FIRST 1 ROWS ONLY";
	final static String OPTION_THREE = "SELECT DATE_YEAR FROM babynames WHERE NAME = 'Rosemary' AND GENDER = 'F' GROUP BY DATE_YEAR ORDER BY COUNT(*) DESC FETCH FIRST 1 ROWS ONLY";
	final static String OPTION_FOUR = "SELECT NAME FROM babynames WHERE DATE_YEAR = 2000 AND US_STATE = 'MD' AND NUM_BABIES > 500";
	final static String OPTION_FIVE = "SELECT US_STATE FROM babynames WHERE DATE_YEAR = 2014 AND NAME = 'Xavier' AND GENDER = 'M' GROUP BY US_STATE ORDER BY COUNT(*) ASC FETCH FIRST 1 ROWS ONLY";
	final static String OPTION_SIX = "SELECT US_STATE FROM babynames WHERE DATE_YEAR =1997 AND NAME = 'Hannah' AND GENDER = 'F' GROUP BY US_STATE ORDER BY COUNT(*) DESC FETCH FIRST 1 ROWS ONLY";
	final static String OPTION_SEVEN1 = "INSERT INTO babynames(ID, NAME, DATE_YEAR, GENDER, US_STATE, NUM_BABIES) VALUES (10000000,'Joseph', 2016, 'M', 'PA', 476)";
	final static String OPTION_SEVEN2 = "SELECT * FROM babynames WHERE ID = 10000000;";
	final static String OPTION_EIGHT = "DELETE FROM babynames WHERE ID = 10000000";

	public static void main(String[]args) {
		Scanner scanner = new Scanner(System.in);
		try(
			Connection conn = DriverManager.getConnection(DB_URL, "user", "password");
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery(TEST_QUERY)
				){
			ResultSetMetaData metaData = resultSet.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			System.out.println("Querying database to check connection:");
			for(int i = 1; i<= numberOfColumns; i++) {
				System.out.printf("%-8s\t", metaData.getColumnName(i));
			}
			System.out.println();
			while(resultSet.next()) {
				for(int i = 1; i<= numberOfColumns; i++) {
					System.out.printf("%-8s\t", resultSet.getObject(i));
					
				}
				System.out.println();
			}
			System.out.println();
		}catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}
		
		selectionMenu(scanner);
		
	}
	public static void selectionMenu(Scanner scanner) {
		int input = 0;
		while (input != 10) {
			
			input =validate_menu_choice(scanner);
			
			switch(input) {
			
			case 1:
				System.out.println("What was the most common boy’s name in Maryland in 1991?");
				optionOne();
				break;
			case 2:
				System.out.println("In which year were the most baby boy’s named “Christopher” born in any state?");
				optionTwo();
				break;
			case 3:
				System.out.println("In which year were the most baby girls named “Rosemary” born in any state?");
				optionThree();
				break;
			case 4:
				System.out.println("In 2000, which baby names were used more than than 500 times in Maryland?");
				optionFour();
				break;
			case 5:
				System.out.println("In 2014, which state had the fewest boys named “Xavier”?");
				optionFive();
				break;
			case 6:
				System.out.println("In 1997, which state had the most girls named “Hannah”?");
				optionSix();
				break;
			case 7:
				System.out.println("Add a new row (no you dont get to choose the contents).");
				optionSeven();
				break;
			case 8:
				System.out.println("Delete the new row.");
				optionEight();
				break;
			case 9:
				System.out.println("Good night.");
				break;

			}
		}
	}
	public static int validate_menu_choice(Scanner scanner) {
		int choice =0;
		do {
			try {
			System.out.println("What would you like to do? (Select the number of your choice)");
			System.out.println("1.) What was the most common boy’s name in Maryland in 1991? \n2.) n which year were the most baby boy’s named “Christopher” born in any state? \n3.) In which year were the most baby girls named “Rosemary” born in any state? \n4.) In 2000, which baby names were used more than than 500 times in Maryland? \n5.) In 2014, which state had the fewest boys named “Xavier”? \n 6.) In 1997, which state had the most girls named “Hannah”? \n7.) Add a new row (no you dont get to choose the contents). \n8.) Delete the new row.");
			choice= scanner.nextInt();
			if(choice < 1 || choice > 11) {
				System.out.println("You may only choose between options 1-10");
			}
		}catch(InputMismatchException ime) {
			System.out.println("Input must be a the number of any of the above options from 1-10");
		}
			
		}while(choice < 1 || choice > 11);
		return choice;
	}
	public static void optionOne() {
		try(
			Connection conn = DriverManager.getConnection(DB_URL, "user", "password");
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery(OPTION_ONE)	
				){
			ResultSetMetaData metaData = resultSet.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			for(int i = 1; i<= numberOfColumns; i++) {
				System.out.printf("%-8s\t", metaData.getColumnName(i));
			}
			System.out.println();
			while(resultSet.next()) {
				for(int i = 1; i<= numberOfColumns; i++) {
					System.out.printf("%-8s\t", resultSet.getObject(i));	
				}
				System.out.println();
			}
			System.out.println();
		}catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}
	}
	public static void optionTwo() {
		try(
			Connection conn = DriverManager.getConnection(DB_URL, "user", "password");
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery(OPTION_TWO)	
				){
			ResultSetMetaData metaData = resultSet.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			for(int i = 1; i<= numberOfColumns; i++) {
				System.out.printf("%-8s\t", metaData.getColumnName(i));
			}
			System.out.println();
			while(resultSet.next()) {
				for(int i = 1; i<= numberOfColumns; i++) {
					System.out.printf("%-8s\t", resultSet.getObject(i));	
				}
				System.out.println();
			}
			System.out.println();
		}catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}
	}
	public static void optionThree() {
		try(
			Connection conn = DriverManager.getConnection(DB_URL, "user", "password");
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery(OPTION_THREE)	
				){
			ResultSetMetaData metaData = resultSet.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			for(int i = 1; i<= numberOfColumns; i++) {
				System.out.printf("%-8s\t", metaData.getColumnName(i));
			}
			System.out.println();
			while(resultSet.next()) {
				for(int i = 1; i<= numberOfColumns; i++) {
					System.out.printf("%-8s\t", resultSet.getObject(i));	
				}
				System.out.println();
			}
			System.out.println();
		}catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}
	}
	public static void optionFour() {
		try(
			Connection conn = DriverManager.getConnection(DB_URL, "user", "password");
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery(OPTION_FOUR)	
				){
			ResultSetMetaData metaData = resultSet.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			for(int i = 1; i<= numberOfColumns; i++) {
				System.out.printf("%-8s\t", metaData.getColumnName(i));
			}
			System.out.println();
			while(resultSet.next()) {
				for(int i = 1; i<= numberOfColumns; i++) {
					System.out.printf("%-8s\t", resultSet.getObject(i));	
				}
				System.out.println();
			}
			System.out.println();
		}catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}		
	}
	public static void optionFive() {
		try(
			Connection conn = DriverManager.getConnection(DB_URL, "user", "password");
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery(OPTION_FIVE)	
				){
			ResultSetMetaData metaData = resultSet.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			for(int i = 1; i<= numberOfColumns; i++) {
				System.out.printf("%-8s\t", metaData.getColumnName(i));
			}
			System.out.println();
			while(resultSet.next()) {
				for(int i = 1; i<= numberOfColumns; i++) {
					System.out.printf("%-8s\t", resultSet.getObject(i));	
				}
				System.out.println();
			}
			System.out.println();
		}catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}	
	}
	public static void optionSix() {
		try(
			Connection conn = DriverManager.getConnection(DB_URL, "user", "password");
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery(OPTION_SIX)	
				){
			ResultSetMetaData metaData = resultSet.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			for(int i = 1; i<= numberOfColumns; i++) {
				System.out.printf("%-8s\t", metaData.getColumnName(i));
			}
			System.out.println();
			while(resultSet.next()) {
				for(int i = 1; i<= numberOfColumns; i++) {
					System.out.printf("%-8s\t", resultSet.getObject(i));	
				}
				System.out.println();
			}
			System.out.println();
		}catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}			
	}
	public static void optionSeven() {
		try(
			Connection conn = DriverManager.getConnection(DB_URL, "user", "password");
			Statement statement = conn.createStatement()
							
				){
			int resultSet1 = statement.executeUpdate(OPTION_SEVEN1);
			System.out.printf("%d Created.%n", resultSet1);
		}catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}	
		
	}
	public static void optionEight() {
		try(
			Connection conn = DriverManager.getConnection(DB_URL, "user", "password");
			Statement statement = conn.createStatement()
							
				){
			int resultSet1 = statement.executeUpdate(OPTION_EIGHT);
			System.out.printf("%d Deleted.%n", resultSet1);
		}catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}	
				
	}
}